// plugins/register.js
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const dbPath = path.join(__dirname, '../usuarios.json')

// Número del OWNER (pon tu número con el formato correcto de WhatsApp)
const OWNER = "51935040872@s.whatsapp.net" // 👈 cámbialo por el tuyo

// Cargar o crear archivo de usuarios
let usuarios = {}
if (fs.existsSync(dbPath)) {
  usuarios = JSON.parse(fs.readFileSync(dbPath))
} else {
  fs.writeFileSync(dbPath, JSON.stringify(usuarios, null, 2))
}

function saveDB() {
  fs.writeFileSync(dbPath, JSON.stringify(usuarios, null, 2))
}

// 👉 Función para obtener el texto de cualquier tipo de mensaje
function getText(m) {
  if (!m.message) return ''
  return (
    m.message.conversation ||
    m.message.extendedTextMessage?.text ||
    m.message.imageMessage?.caption ||
    m.message.videoMessage?.caption ||
    ''
  )
}

export default function (sock) {
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0]
    if (!m.message) return // ⚠️ YA NO IGNORAMOS "fromMe"

    const jid = m.key.remoteJid // chat donde se manda
    const sender = m.key.participant || jid // quién mandó
    const text = getText(m).trim()

    const isOwner = sender === OWNER

    // 📌 Registrar usuario -> /reg Nombre.Edad
    if (text.toLowerCase().startsWith('/reg')) {
      const args = text.slice(4).trim()
      if (!args.includes('.')) {
        await sock.sendMessage(jid, { text: '⚠️ Formato incorrecto.\nUsa: /reg Nombre.Edad' }, { quoted: m })
        return
      }

      const [nombre, edad] = args.split('.')
      if (!nombre || !edad) {
        await sock.sendMessage(jid, { text: '⚠️ Debes poner tu nombre y edad.\nEjemplo: /reg Jahseh.17' }, { quoted: m })
        return
      }

      usuarios[sender] = { nombre, edad, registrado: true }
      saveDB()

      await sock.sendMessage(jid, {
        text: `✅ Registrado correctamente!\n👤 Nombre: *${nombre}*\n🎂 Edad: *${edad}*\n\nYa puedes usar el comando .menu 🚀`
      }, { quoted: m })
      return
    }

    // 📌 Verificación en .menu /menu .bot
    if (['.menu', '/menu', '.bot'].includes(text.toLowerCase())) {
      if (!isOwner && (!usuarios[sender] || !usuarios[sender].registrado)) {
        await sock.sendMessage(jid, {
          text: `⚠️ Aún no estás registrado.\nRegístrate usando:\n👉 */reg Nombre.Edad*\n\nEjemplo:\n/reg Jahseh.17`
        }, { quoted: m })
        return
      }

      // 👉 El menú lo responde tu otro plugin .menu
      console.log(`📌 Menú solicitado por: ${isOwner ? "OWNER" : usuarios[sender].nombre}`)
    }

    // 📌 Comando XP -> funciona siempre
    if (text.toLowerCase() === '.xp') {
      await sock.sendMessage(jid, { text: '💎 Aquí están tus puntos de experiencia!' }, { quoted: m })
    }
  })
}
